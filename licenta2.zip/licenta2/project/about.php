<?php  

include 'components/connect.php';

if(isset($_COOKIE['user_id'])){
   $user_id = $_COOKIE['user_id'];
}else{
   $user_id = '';
}

?>

<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title>About Us</title>

   <!-- font awesome cdn link  -->
   <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.2.0/css/all.min.css">

   <!-- custom css file link  -->
   <link rel="stylesheet" href="css/style.css">

</head>
<body>
   
<?php include 'components/user_header.php'; ?>

<!-- about section starts  -->

<section class="about">

   <div class="row">
      <div class="image">
         <img src="images/about-img.svg" alt="">
      </div>
      <div class="content">
         <h3>why choose us?</h3>
         <p>We’re more than just a real estate agency—we’re your trusted partner in finding the perfect property.
             With years of experience, personalized service, and a deep understanding of the market, we ensure your journey is smooth and rewarding.
             Choose us for professionalism, integrity, and results that exceed expectations!</p>
         <a href="contact.php" class="inline-btn">contact us</a>
      </div>
   </div>

</section>

<!-- about section ends -->

<!-- steps section starts  -->

<section class="steps">

   <h1 class="heading">3 simple steps</h1>

   <div class="box-container">

      <div class="box">
         <img src="images/step-1.png" alt="">
         <h3>search property</h3>
         <p>Easily browse through our wide selection of properties to find the one that suits your needs.
            From cozy apartments to luxurious homes and commercial spaces, we make your property search simple and stress-free.
            Start exploring today!</p>
      </div>

      <div class="box">
         <img src="images/step-2.png" alt="">
         <h3>contact agents</h3>
         <p>Our expert agents are here to help you with all your real estate needs. Whether you’re buying, selling, or renting,
             we provide personalized guidance to ensure you make the best decision.
             Contact us today and let us assist you every step of the way!</p>
      </div>

      <div class="box">
         <img src="images/step-3.png" alt="">
         <h3>enjoy property</h3>
         <p>Experience the comfort and satisfaction of living or working in the perfect space.
             Our properties are carefully selected to provide you with the ideal environment to enjoy your lifestyle.
             Let us help you find a place you'll love to call home or your work place!</p>
      </div>

   </div>

</section>

<!-- steps section ends -->

<!-- review section starts  -->

<section class="reviews">

   <h1 class="heading">client's reviews</h1>

   <div class="box-container">

      <div class="box">
         <div class="user">
            <img src="images/pic-1.png" alt="">
            <div>
               <h3>Liam</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
         <p>I recently worked with NovaHouse to buy my new home, and I couldn’t be happier!
             The team was incredibly professional and responsive throughout the entire process.
              They took the time to understand my needs and helped me find the perfect place.
             Highly recommend NovaHouse to anyone!</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-2.png" alt="">
            <div>
               <h3>Sophia</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
         <p>My experience with NovaHouse was exceptional. From the first consultation to the final paperwork,
             the team made everything so easy and stress-free. They offered great advice and found me a fantastic
              property that matched all my requirements.
             I’ll definitely work with them again in the future!</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-3.png" alt="">
            <div>
               <h3>Ethan</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
         <p>Working with NovaHouse was an absolute pleasure. Their attention to detail and dedication to finding the right
             property for me was evident from day one. They made the entire process of buying my home straightforward and enjoyable.
             I highly recommend NovaHouse for anyone looking to make a move!</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-4.png" alt="">
            <div>
               <h3>Emma</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
         <p>NovaHouse went above and beyond in helping me find the perfect rental property.
             They understood my budget and preferences and found me an amazing place quickly.
             I am so grateful for their professionalism and support. Thank you, NovaHouse!</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-5.png" alt="">
            <div>
               <h3>James</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
         <p>I had a great experience selling my apartment with NovaHouse. The team was knowledgeable, professional, and efficient,
             keeping me well-informed throughout the process. I’ll definitely recommend NovaHouse to friends and family!</p>
      </div>

      <div class="box">
         <div class="user">
            <img src="images/pic-6.png" alt="">
            <div>
               <h3>Olivia</h3>
               <div class="stars">
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
                  <i class="fas fa-star"></i>
               </div>
            </div>
         </div>
         <p>I had an amazing experience with NovaHouse when selling my property. The team was professional,
             reliable, and always available to answer my questions.
             They made the entire process smooth and stress-free. Highly recommend their services!</p>
      </div>

   </div>

</section>

<!-- review section ends -->










<?php include 'components/footer.php'; ?>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>